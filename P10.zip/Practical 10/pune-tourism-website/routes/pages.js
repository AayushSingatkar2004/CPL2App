const express = require('express');
const router = express.Router();

// Home Page
router.get('/', (req, res) => {
    res.render('home', { title: "Home - Pune Tourism" });

});

// Heritage Page
router.get('/heritage', (req, res) => {
    res.render('heritage', { title: "Heritage - Pune Tourism" });
});

// Hotel Booking Page
router.get('/hotels', (req, res) => {
    res.render('hotels', { title: "Hotel Booking - Pune Tourism" });
});

// Gallery Page
router.get('/gallery', (req, res) => {
    res.render('gallery', { title: "Gallery - Pune Tourism" });
});

// Contact Page
router.get('/contact', (req, res) => {
    res.render('contact', { title: "Contact - Pune Tourism" });
});

// About Page
router.get('/about', (req, res) => {
    res.render('about', { title: "About - Pune Tourism" });
});

// Food Page
router.get('/food', (req, res) => {
    res.render('food', { title: "Food - Pune Tourism" });
});

// Transport Page
router.get('/transport', (req, res) => {
    res.render('transport', { title: "Transport - Pune Tourism" });
});

// Places Page
router.get('/places', (req, res) => {
    res.render('places', { title: "Places - Pune Tourism" });
});

// Events Page
router.get('/events', (req, res) => {
    res.render('events', { title: "Events - Pune Tourism" });
});

module.exports = router;
