# Pune Tourism Website 🌆

A full-stack website showcasing popular tourism sites in Pune. Built using Node.js, Express, and EJS.

## 🛠 Tech Stack

- Frontend: HTML, CSS, EJS
- Backend: Node.js, Express
- Database: MongoDB (for hotel booking/contact form)

## 📂 Pages

- Home
- Heritage
- Hotel Booking
- Gallery
- About Us
- Contact
- Restaurants
- Events
- Places to Visit
- Map/Transport

## 🚀 How to Run

1. Clone the repository:

2. Install dependencies:

3. Run the app:

4. Visit `http://localhost:3000` in your browser.

## 📷 Screenshots

_Add screenshots here if needed._

## 📬 Contact

Created by [Your Name]. Feel free to reach out!

