const products = [
    {
      image: "https://rukminim2.flixcart.com/image/850/1000/xif0q/shopsy-smartwatch/p/b/6/1-44-android-ios-t500-smart-watch-with-bluetooth-calling-black-original-imagvy24hyyqbzvm.jpeg?q=90&crop=false",
      name: "Smart Watch",
      price: "₹2,999"
    },
    {
      image: "https://m.media-amazon.com/images/I/61k8s2-fKHL._AC_UF1000,1000_QL80_.jpg",
      name: "Wireless Earbuds",
      price: "₹1,499"
    },
    {
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLQLdHTfNNMG2gef1eHJyaSyItIYPXSQCdpw&s",
      name: "Fitness Band",
      price: "₹1,999"
    },
    {
      image: "https://m.media-amazon.com/images/I/71d7rfSl0wL._SX679_.jpg",
      name: "Smartphone",
      price: "₹14,999"
    },
    {
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYC9lQV8FBTauviAK_BntKM-wBBwTGVqrIvA&s",
      name: "Tablet",
      price: "₹9,499"
    },
    {
      image: "https://m.media-amazon.com/images/I/71WuDXpTAlL._SX679_.jpg",
      name: "Laptop",
      price: "₹39,999"
    },
    {
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREJ10C6v5lCmFrxRFDSPGpTnBGMYSe5uEF3A&s",
      name: "Smart TV",
      price: "₹24,999"
    },
    {
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuAvU3-uz13LNVhjc6HCKGVREFiseFmVfRHA&s",
      name: "Bluetooth Speaker",
      price: "₹1,199"
    }
  ];
  